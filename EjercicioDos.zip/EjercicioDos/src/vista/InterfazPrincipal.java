package vista;

import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import mundo.Equipaje;

/**
 *
 * @author arley
 */
public class InterfazPrincipal extends javax.swing.JFrame {
    /*
    * CONSTANTES.   
    */
    private final double PRECIO_DOLAR = 3272.14;
    
    private final double PESO_MAXIMO = 18000;
    
    /*
    * ATRIBUTOS.   
    */
    private DefaultTableModel modeloTablaEquipaje;
    
    private ArrayList<Equipaje> listaEquipaje;
    
    private DialogAgregarEquipaje dialogAgregarEquipaje;
    
    private int totalBultos;
    
    private double pesoTotal = 0;
    
    private double pesoBultoMaxPesado;
    
    private double pesoBultoMaxLiviano;
    
    private double pesoPromedioBultos;
    
    private double ingresoPesos;
    
    private double ingresoDolares;
    
    private Equipaje equipaje;
    
    
    /*
    * CONTRUCTOR.
    */
    public InterfazPrincipal() {
        initComponents();
        this.disenarTabla(); 
        this.listaEquipaje = new ArrayList<Equipaje>();
    }

    
    /*
    * MÉTODOS.
    */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablaEquipaje = new javax.swing.JTable();
        fondoBtnAgregarEquipaje = new javax.swing.JPanel();
        btnAgregarEquipaje = new javax.swing.JLabel();
        lblNumeroTotalBultos = new javax.swing.JLabel();
        lblBultoMasPesado = new javax.swing.JLabel();
        lblBultoMasLiviano = new javax.swing.JLabel();
        lblPesoPromedio = new javax.swing.JLabel();
        lblIngresosPeso = new javax.swing.JLabel();
        lblIngresoDolares = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(770, 500));
        setMinimumSize(new java.awt.Dimension(770, 500));
        setPreferredSize(new java.awt.Dimension(770, 500));

        jPanel1.setBackground(new java.awt.Color(238, 238, 238));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Recepción Equipajes", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 16), new java.awt.Color(3, 69, 102))); // NOI18N
        jPanel1.setMaximumSize(new java.awt.Dimension(700, 500));
        jPanel1.setMinimumSize(new java.awt.Dimension(700, 500));

        tablaEquipaje.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(tablaEquipaje);

        fondoBtnAgregarEquipaje.setBackground(new java.awt.Color(3, 69, 102));
        fondoBtnAgregarEquipaje.setMaximumSize(new java.awt.Dimension(80, 25));
        fondoBtnAgregarEquipaje.setMinimumSize(new java.awt.Dimension(80, 25));
        fondoBtnAgregarEquipaje.setLayout(new java.awt.BorderLayout());

        btnAgregarEquipaje.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnAgregarEquipaje.setForeground(new java.awt.Color(238, 238, 238));
        btnAgregarEquipaje.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnAgregarEquipaje.setText("Agregar");
        btnAgregarEquipaje.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAgregarEquipajeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAgregarEquipajeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAgregarEquipajeMouseExited(evt);
            }
        });
        fondoBtnAgregarEquipaje.add(btnAgregarEquipaje, java.awt.BorderLayout.CENTER);

        lblNumeroTotalBultos.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblNumeroTotalBultos.setForeground(new java.awt.Color(3, 69, 102));
        lblNumeroTotalBultos.setText("N° Total Bultos:");

        lblBultoMasPesado.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblBultoMasPesado.setForeground(new java.awt.Color(3, 69, 102));
        lblBultoMasPesado.setText("Peso Bulto Más Pesado:");

        lblBultoMasLiviano.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblBultoMasLiviano.setForeground(new java.awt.Color(3, 69, 102));
        lblBultoMasLiviano.setText("Peso Bulto Más Liviano:");

        lblPesoPromedio.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblPesoPromedio.setForeground(new java.awt.Color(3, 69, 102));
        lblPesoPromedio.setText("Peso Promedio:");

        lblIngresosPeso.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblIngresosPeso.setForeground(new java.awt.Color(3, 69, 102));
        lblIngresosPeso.setText("Ingresos En Pesos:");

        lblIngresoDolares.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblIngresoDolares.setForeground(new java.awt.Color(3, 69, 102));
        lblIngresoDolares.setText("Ingresos En Dolares:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNumeroTotalBultos)
                            .addComponent(lblBultoMasPesado)
                            .addComponent(lblBultoMasLiviano)
                            .addComponent(lblPesoPromedio)
                            .addComponent(lblIngresosPeso)
                            .addComponent(lblIngresoDolares)))
                    .addComponent(fondoBtnAgregarEquipaje, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(120, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(fondoBtnAgregarEquipaje, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblNumeroTotalBultos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblBultoMasPesado)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblBultoMasLiviano)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblPesoPromedio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblIngresosPeso)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblIngresoDolares)))
                .addContainerGap(91, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    private void disenarTabla(){
        this.modeloTablaEquipaje = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int rows, int colunms){
                return false;
            }
        };
        
        String [] tablaClientesTitulos = new String[]{"PROPIETARIO", "DESCRIPCIÓN", "PESO", "VALOR"};
        this.modeloTablaEquipaje.setColumnIdentifiers(tablaClientesTitulos);
        this.tablaEquipaje.setModel(modeloTablaEquipaje);
        this.tablaEquipaje.setForeground(new Color(3,69,102));
    }
    
    private void agregarEquipaje(){
        this.dialogAgregarEquipaje = new DialogAgregarEquipaje(this, true);
        this.dialogAgregarEquipaje.setVisible(true);
        if(this.dialogAgregarEquipaje.getEquipaje() != null){
            //Validamos que no sobrepase la carga maxima del vehiculo.
            if(this.pesoTotal + this.dialogAgregarEquipaje.getEquipaje().getPeso() > this.PESO_MAXIMO){
                JOptionPane.showMessageDialog(this, "No se puede agregar el equipaje por que sobrepasa\n el peso maximo que soporta el vehiculo.");
            }else{         
            this.listaEquipaje.add(this.dialogAgregarEquipaje.getEquipaje());
            this.cargarSeguimientoTabla();
            }
        }
    }
    
    private void limpiarTabla(){  
        int filas = this.modeloTablaEquipaje.getRowCount();
        for(int i = 0; i < filas ; i++){
            this.modeloTablaEquipaje.removeRow(0);
        }
    }
    
    private void cargarSeguimientoTabla(){  
        this.limpiarTabla();
        this.totalBultos = 0;
        this.pesoBultoMaxPesado = 0;
        this.pesoBultoMaxLiviano = 501;
        this.pesoPromedioBultos = 0;
        this.ingresoPesos = 0;
        this.ingresoDolares = 0;
        //Agrego Información A La Tabla Y Extraigo Informacion.
        for (Equipaje equipaje : listaEquipaje) {
            this.modeloTablaEquipaje.addRow(new Object[]{
                equipaje.getPropietario(), equipaje.getDescripcion(), equipaje.getPeso(), equipaje.getValor()
            });
            //Extraigo Total De Bultos.
            this.totalBultos++;
            //Extraigo El Peso Más Alto De Los Bultos.
            if(equipaje.getPeso() > this.pesoBultoMaxPesado){
                this.pesoBultoMaxPesado = equipaje.getPeso();
            }
            //Extraigo El Peso Más Liviano De Los Bultos.
            if(equipaje.getPeso() < this.pesoBultoMaxLiviano){
                this.pesoBultoMaxLiviano = equipaje.getPeso();
            }
            //Acomulo Los Pesos.
            this.pesoPromedioBultos+= equipaje.getPeso();
            //Acomulo Ingresos En Pesos.
            this.ingresoPesos += equipaje.getValor();
        }     
        //Calculo El Promedio De Pesos.
        this.pesoPromedioBultos = Math.ceil(this.pesoPromedioBultos/this.totalBultos);
        //reducimos decimales
        this.ingresoPesos = Math.ceil(this.ingresoPesos);
        //Calculamos Ingresos En Dolares.
        this.ingresoDolares = Math.ceil(this.ingresoPesos/this.PRECIO_DOLAR);
        this.asignarValoresCalculadosDelSeguimiento();
    }
    
    private void asignarValoresCalculadosDelSeguimiento(){
        //Asignamos Total Bultos
        this.lblNumeroTotalBultos.setText("N° Total Bultos: "+this.totalBultos);
        //Asignamos Peso Del Bulto Más Pesado.
        this.lblBultoMasPesado.setText("Peso Bulto Más Pesado: "+this.pesoBultoMaxPesado);
        //Asignamos Peso Del Bulto Más Liviano.
        this.lblBultoMasLiviano.setText("Peso Bulto Más Liviano: "+this.pesoBultoMaxLiviano);
        // Asignamos Peso Promedio De Los Bultos.
        this.lblPesoPromedio.setText("Peso Promedio: "+this.pesoPromedioBultos);
        // Asignamos Ingresos En Pesos.
        this.lblIngresosPeso.setText("Ingresos En Pesos: "+this.ingresoPesos);
        // Asignamos Ingresos En Dolares.
        this.lblIngresoDolares.setText("Ingresos En Dolares: "+this.ingresoDolares);
    }
    
    /*
    * EVENTOS.
    */    
    private void btnAgregarEquipajeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarEquipajeMouseClicked
        this.agregarEquipaje();
    }//GEN-LAST:event_btnAgregarEquipajeMouseClicked

    private void btnAgregarEquipajeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarEquipajeMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAgregarEquipajeMouseEntered

    private void btnAgregarEquipajeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarEquipajeMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAgregarEquipajeMouseExited

    /*
    * MÉTODO MAIN
    */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfazPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btnAgregarEquipaje;
    private javax.swing.JPanel fondoBtnAgregarEquipaje;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lblBultoMasLiviano;
    private javax.swing.JLabel lblBultoMasPesado;
    private javax.swing.JLabel lblIngresoDolares;
    private javax.swing.JLabel lblIngresosPeso;
    private javax.swing.JLabel lblNumeroTotalBultos;
    private javax.swing.JLabel lblPesoPromedio;
    private javax.swing.JTable tablaClientes;
    private javax.swing.JTable tablaClientes1;
    private javax.swing.JTable tablaClientes2;
    private javax.swing.JTable tablaEquipaje;
    // End of variables declaration//GEN-END:variables
}

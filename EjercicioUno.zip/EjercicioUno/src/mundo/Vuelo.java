package mundo;

/**
 *
 * @author arley
 */
public class Vuelo {
    /*
    * CONSTANTES.
    */
    public final double PRECIO_POR_KILOMETRO = 35;
    
    /*
    * ATRIBUTOS.
    */
    private int distanciaRecorrida;
    
    private int diasEstancia;
    
    private String nombreVuelo;
    
    private String origen;
    
    private String destino;
    
    private double valorVuelo;
    
    /*
    * CONSTRUCTORES.
    */
    public Vuelo(String pNombreVuelo, String pOrigen, String pDestino, int pDistanciaRecorrida, int pDiasEstancia){
        this.origen = pOrigen;
        this.destino = pDestino;
        this.nombreVuelo = pNombreVuelo;
        this.distanciaRecorrida = pDistanciaRecorrida;
        this.diasEstancia = pDiasEstancia;
        this.calcularValorVuelo();
    }

    
    /*
    * MÉTODOS.
    */
    public int getDistanciaRecorrida() {
        
        return distanciaRecorrida;
    }

    public void setDistanciaRecorrida(int distanciaRecorrida) {
        this.distanciaRecorrida = distanciaRecorrida;
    }

    public int getDiasEstancia() {
        return diasEstancia;
    }

    public void setDiasEstancia(int diasEstancia) {
        this.diasEstancia = diasEstancia;
    }

    public String getNombreVuelo() {
        return nombreVuelo;
    }

    public void setNombreVuelo(String nombreVuelo) {
        this.nombreVuelo = nombreVuelo;
    }

    public double getValorVuelo() {
        return valorVuelo;
    }

    public void setValorVuelo(double valorVuelo) {
        this.valorVuelo = valorVuelo;
    }
    
    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }
    
    private void calcularValorVuelo() {
        this.valorVuelo = this.PRECIO_POR_KILOMETRO * this.distanciaRecorrida;
    }
    
    public double aplicarDescuento(){
         return this.valorVuelo - (this.valorVuelo * 0.30);
    }
    
}

package vista;

import java.awt.Color;
import javax.swing.JOptionPane;
import mundo.Vuelo;

/**
 *
 * @author arley
 */
public class InterfazPrincipal extends javax.swing.JFrame {
    /*
    * ATRIBUTOS.
    */
    private Vuelo vuelo;
    
    private int distanciaVuelo;
    
    /*
    * CONSTRUCTORES.
    */
    public InterfazPrincipal() {
        initComponents();
    }

    
    /*
    * METODOS.
    */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        fondoBtnCalcular = new javax.swing.JPanel();
        btnCalcular = new javax.swing.JLabel();
        txtNombreVuelo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        sprDiasEstancia = new javax.swing.JSpinner();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cboOrigen = new javax.swing.JComboBox();
        cboDestino = new javax.swing.JComboBox();
        lblDistancia = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Vuelos");
        setMinimumSize(new java.awt.Dimension(400, 300));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(238, 238, 238));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Calculo Vuelo", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 16), new java.awt.Color(3, 69, 102))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(3, 69, 102));
        jLabel1.setText("Nombre del vuelo:");

        fondoBtnCalcular.setBackground(new java.awt.Color(3, 69, 102));
        fondoBtnCalcular.setMaximumSize(new java.awt.Dimension(80, 25));
        fondoBtnCalcular.setMinimumSize(new java.awt.Dimension(80, 25));
        fondoBtnCalcular.setLayout(new java.awt.BorderLayout());

        btnCalcular.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnCalcular.setForeground(new java.awt.Color(238, 238, 238));
        btnCalcular.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnCalcular.setText("Calcular");
        btnCalcular.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCalcularMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCalcularMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCalcularMouseExited(evt);
            }
        });
        fondoBtnCalcular.add(btnCalcular, java.awt.BorderLayout.CENTER);

        txtNombreVuelo.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtNombreVuelo.setForeground(new java.awt.Color(3, 69, 102));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(3, 69, 102));
        jLabel2.setText("Dias de estancia:");

        sprDiasEstancia.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        sprDiasEstancia.setMaximumSize(new java.awt.Dimension(29, 23));
        sprDiasEstancia.setMinimumSize(new java.awt.Dimension(29, 23));
        sprDiasEstancia.setPreferredSize(new java.awt.Dimension(29, 23));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(3, 69, 102));
        jLabel3.setText("Origen:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(3, 69, 102));
        jLabel4.setText("Destino:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(3, 69, 102));
        jLabel5.setText("Distancia:");

        cboOrigen.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        cboOrigen.setForeground(new java.awt.Color(3, 69, 102));
        cboOrigen.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Medellín", "Cartagéna", "Santa Marta", "China", "España", " " }));
        cboOrigen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrigenActionPerformed(evt);
            }
        });

        cboDestino.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        cboDestino.setForeground(new java.awt.Color(3, 69, 102));
        cboDestino.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Medellín", "Cartagéna", "Santa Marta", "China", "España", " " }));
        cboDestino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboDestinoActionPerformed(evt);
            }
        });

        lblDistancia.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblDistancia.setForeground(new java.awt.Color(0, 204, 51));
        lblDistancia.setText("0 km:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(txtNombreVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(sprDiasEstancia, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(44, 44, 44))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(cboOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cboDestino, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblDistancia)
                                .addGap(0, 24, Short.MAX_VALUE)))
                        .addGap(23, 23, 23))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(164, 164, 164)
                .addComponent(fondoBtnCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombreVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sprDiasEstancia, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboDestino, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblDistancia))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(fondoBtnCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public boolean validarFormularioVuelo(){
        if(this.txtNombreVuelo.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "¡Por favor! \nIngrese un nombre valido para el vuelo.");
            return false;
        }
        if(this.cboOrigen.getSelectedItem().toString().equals(this.cboDestino.getSelectedItem().toString())){
            JOptionPane.showMessageDialog(this, "¡Por favor! \nElige destinos diferentes");
            return false;
        }
        if((int) this.sprDiasEstancia.getValue() < 1){
            JOptionPane.showMessageDialog(this, "¡Por favor! \nIngrese un valor de dias superior a 0");
            return false;
        }
        return true;
    }
    
    public void calcularVuelo(){
        if(this.validarFormularioVuelo()){
            this.vuelo = new Vuelo(this.txtNombreVuelo.getText(), this.cboOrigen.getSelectedItem().toString(), this.cboDestino.getSelectedItem().toString(), this.distanciaVuelo, (int) this.sprDiasEstancia.getValue());
            if(this.vuelo.getDistanciaRecorrida() > 1000 && this.vuelo.getDiasEstancia() > 7){
                JOptionPane.showMessageDialog(this, "Vuelo: "+this.vuelo.getNombreVuelo()+"\nOrigen: "+this.vuelo.getOrigen()+"\nDestino: "+this.vuelo.getDestino()+"\nDistancia : "+this.vuelo.getDistanciaRecorrida()+"\nDias Estancia: "+this.vuelo.getDiasEstancia()+"\nTIENE UN DESCUENTO DEL 30%. \nValor Sin Descuento :"+this.vuelo.getValorVuelo()+"\nValor Con Descuento: "+this.vuelo.aplicarDescuento());
            }else{
                JOptionPane.showMessageDialog(this, "Vuelo: "+this.vuelo.getNombreVuelo()+"\nOrigen: "+this.vuelo.getOrigen()+"\nDestino: "+this.vuelo.getDestino()+"\nDistancia : "+this.vuelo.getDistanciaRecorrida()+"\nDias Estancia: "+this.vuelo.getDiasEstancia()+"\nValor Del Vuelo :"+this.vuelo.getValorVuelo());
            }
        }
    }
    
    public void calcularDistancia(){
        if(this.cboOrigen.getSelectedItem().toString().equals("Medellín") && this.cboDestino.getSelectedItem().toString().equals("Medellín")){
            this.distanciaVuelo = 0;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("Medellín") && this.cboDestino.getSelectedItem().toString().equals("Cartagéna") || this.cboOrigen.getSelectedItem().toString().equals("Cartagéna") && this.cboDestino.getSelectedItem().toString().equals("Medellín")){
            this.distanciaVuelo = 460;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("Medellín") && this.cboDestino.getSelectedItem().toString().equals("Santa Marta") || this.cboOrigen.getSelectedItem().toString().equals("Santa Marta") && this.cboDestino.getSelectedItem().toString().equals("Medellín")){
            this.distanciaVuelo = 405;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("Medellín") && this.cboDestino.getSelectedItem().toString().equals("España") || this.cboOrigen.getSelectedItem().toString().equals("España") && this.cboDestino.getSelectedItem().toString().equals("Medellín")){
            this.distanciaVuelo = 1000;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("Medellín") && this.cboDestino.getSelectedItem().toString().equals("China") || this.cboOrigen.getSelectedItem().toString().equals("China") && this.cboDestino.getSelectedItem().toString().equals("Medellín")){
            this.distanciaVuelo = 1800;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        

        if(this.cboOrigen.getSelectedItem().toString().equals("Cartagéna") && this.cboDestino.getSelectedItem().toString().equals("Cartagéna")){
            this.distanciaVuelo = 0;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("Cartagéna") && this.cboDestino.getSelectedItem().toString().equals("Santa Marta") || this.cboOrigen.getSelectedItem().toString().equals("Santa Marta") && this.cboDestino.getSelectedItem().toString().equals("Cartagéna")){
            this.distanciaVuelo = 115;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("Cartagéna") && this.cboDestino.getSelectedItem().toString().equals("China") || this.cboOrigen.getSelectedItem().toString().equals("China") && this.cboDestino.getSelectedItem().toString().equals("Cartagéna")){
            this.distanciaVuelo = 1777;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("Cartagéna") && this.cboDestino.getSelectedItem().toString().equals("España") || this.cboOrigen.getSelectedItem().toString().equals("España") && this.cboDestino.getSelectedItem().toString().equals("Cartagéna")){
            this.distanciaVuelo = 1010;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        
        
        if(this.cboOrigen.getSelectedItem().toString().equals("Santa Marta") && this.cboDestino.getSelectedItem().toString().equals("Santa Marta")){
            this.distanciaVuelo = 0;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("Santa Marta") && this.cboDestino.getSelectedItem().toString().equals("China") || this.cboOrigen.getSelectedItem().toString().equals("China") && this.cboDestino.getSelectedItem().toString().equals("Santa Marta")){
            this.distanciaVuelo = 1690;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("Santa Marta") && this.cboDestino.getSelectedItem().toString().equals("España") || this.cboOrigen.getSelectedItem().toString().equals("España") && this.cboDestino.getSelectedItem().toString().equals("Santa Marta")){
            this.distanciaVuelo = 1030;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        
        
        if(this.cboOrigen.getSelectedItem().toString().equals("España") && this.cboDestino.getSelectedItem().toString().equals("España")){
            this.distanciaVuelo = 0;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
        if(this.cboOrigen.getSelectedItem().toString().equals("España") && this.cboDestino.getSelectedItem().toString().equals("China") || this.cboOrigen.getSelectedItem().toString().equals("China") && this.cboDestino.getSelectedItem().toString().equals("España")){
            this.distanciaVuelo = 999;
            this.lblDistancia.setText(this.distanciaVuelo+" km");
        }
    }
    
    /*
    * EVENTOS.
    */
    private void btnCalcularMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCalcularMouseClicked
        this.calcularVuelo();
    }//GEN-LAST:event_btnCalcularMouseClicked

    private void cboOrigenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrigenActionPerformed
        this.calcularDistancia();
    }//GEN-LAST:event_cboOrigenActionPerformed

    private void cboDestinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboDestinoActionPerformed
        this.calcularDistancia();
    }//GEN-LAST:event_cboDestinoActionPerformed

    private void btnCalcularMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCalcularMouseEntered
        this.fondoBtnCalcular.setBackground(new Color(0,204,51));
    }//GEN-LAST:event_btnCalcularMouseEntered

    private void btnCalcularMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCalcularMouseExited
        this.fondoBtnCalcular.setBackground(new Color(3,69,102));
    }//GEN-LAST:event_btnCalcularMouseExited
     
    
    /*
    * METODO MAIN.
    */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfazPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btnCalcular;
    private javax.swing.JComboBox cboDestino;
    private javax.swing.JComboBox cboOrigen;
    private javax.swing.JPanel fondoBtnCalcular;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblDistancia;
    private javax.swing.JSpinner sprDiasEstancia;
    private javax.swing.JTextField txtNombreVuelo;
    // End of variables declaration//GEN-END:variables
}
